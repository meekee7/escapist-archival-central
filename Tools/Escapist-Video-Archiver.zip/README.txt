Usage: Open a command line or powershell. Start EscapistVideoArchiver like this:
.\EscapistVideoArchiver.exe -start 1 -end 10 -cont mp4 -res 480
Start refers to the first video id (inclusive)
End refers to the last video id (inclusive)
Cont is the container: WebM or MP4
Res is the resolution: 360p or 480p

To cancel the program press Ctrl + C
Error handling is not very sophisticated. Tell me if something goes wrong. 
Usage at your own risk.

Videos will be stored in a subdirectory of the execution directory of the program.
If a preexisting video is already downloaded it will be overwritten.

EscapistFetch and ZPDBAnalyzer are dependencies of EscapistVideoArchiver (sort of like DLLs). 
If you execute them they will do nothing.


Built-in safety precautions:
The id range is limited to 500 videos at a time.
There is a four second gap between downloads.

